package com.example.quickjob.Activities

import android.content.Intent
import android.os.Bundle
import android.support.design.widget.FloatingActionButton
import android.support.design.widget.Snackbar
import androidx.navigation.findNavController
import android.support.v4.widget.DrawerLayout
import android.support.design.widget.NavigationView
import android.support.v4.view.GravityCompat
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.Toolbar
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.navigation.ui.*
import com.example.quickjob.R
import com.google.firebase.auth.FirebaseAuth

class HomeActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var mAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        val fab: FloatingActionButton = findViewById(R.id.fab)
        fab.setOnClickListener {
            val newAdIntent = Intent(applicationContext,NewAdActivity::class.java)
            startActivity(newAdIntent)
        }

        mAuth = FirebaseAuth.getInstance()

        val drawerLayout: DrawerLayout = findViewById(R.id.drawer_layout)
        val navView: NavigationView = findViewById(R.id.nav_view)
        navView.setNavigationItemSelectedListener(this)
        val navController = findNavController(R.id.nav_host_fragment)

        refreshNavHeader()

        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.nav_home, R.id.nav_gallery, R.id.nav_map,
                R.id.nav_tools, R.id.nav_share
            ), drawerLayout
        )
        setupActionBarWithNavController(navController, appBarConfiguration)
        navView.setupWithNavController(navController)
    }

    private fun refreshNavHeader() {
        val navView: NavigationView = findViewById(R.id.nav_view)
        val headerView: View = navView.getHeaderView(0)
        val userName:TextView = headerView.findViewById(R.id.nav_user_name)
        val userEmail: TextView = headerView.findViewById(R.id.nav_user_email)
        val userImage: ImageView = headerView.findViewById(R.id.nav_userimage)
        val currentuser = mAuth.currentUser

        if(currentuser != null) {
            userName.text = currentuser.displayName
            userEmail.text = currentuser.email
        }else{

            userName.text = "Log in to unblock new things!"
            userEmail.text = ""
            userImage.setImageResource(R.drawable.worker)

        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.home, menu)
        return true
    }


    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment)
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {

        if(item.itemId == R.id.nav_logout){

                FirebaseAuth.getInstance().signOut()
                Toast.makeText(applicationContext,"Log out",Toast.LENGTH_LONG).show()
            }

        findViewById<DrawerLayout>(R.id.drawer_layout).closeDrawer(GravityCompat.START)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {

        if(item!!.itemId == R.id.action_settings){
            FirebaseAuth.getInstance().signOut()
            Toast.makeText(applicationContext,"Log out",Toast.LENGTH_LONG).show()
            refreshNavHeader()
        }

        return true
    }

/*override fun onStart() {
    super.onStart()

    val currentUser = mAuth.currentUser

    if(currentUser == null){
        val login = Intent(applicationContext,LoginActivity::class.java)
        startActivity(login)
    }
}*/


}
