package com.example.quickjob.Activities

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.Toast
import com.example.quickjob.R
import java.lang.Exception

class NewAdActivity : AppCompatActivity() {

    lateinit var img: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_ad)

        img = findViewById(R.id.new_ad_img)

        /*img.setOnClickListener{

            CropImage.activity()
                .setGuidelines(CropImageView.Guidelines.ON)
                .start(this)
        }*/

    }

   /* override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if(requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE){
            val result: CropImage.ActivityResult = CropImage.getActivityResult(data)
            if(resultCode == Activity.RESULT_OK){
                val resultUri: Uri = result.uri
                img.setImageURI(resultUri)
            }else if(resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE){
                val error: Exception = result.error
                Toast.makeText(applicationContext,"Crop image error : $error",Toast.LENGTH_SHORT).show()
            }
        }
    }*/
}
