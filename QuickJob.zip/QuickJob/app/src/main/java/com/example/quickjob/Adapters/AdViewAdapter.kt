package com.example.quickjob.Adapters

import android.content.Context
import android.icu.text.DateFormat
import android.location.Location
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.quickjob.Classes.Advertisement
import com.example.quickjob.R
import com.google.android.gms.common.api.GoogleApi
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.GoogleMapOptions
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.SphericalUtil
import org.w3c.dom.Text
import java.util.*

class AdViewAdapter(private var context: Context, list: Array<Advertisement>) :
    RecyclerView.Adapter<AdViewAdapter.MyViewHolder>() {

    private var adList: Array<Advertisement> = list
    private var options : RequestOptions
    private lateinit var fusedLocationClient: FusedLocationProviderClient


    init {
        options = RequestOptions()
            .centerCrop()
            .placeholder(R.drawable.loading_shape)
            .error(R.drawable.loading_shape)
    }

    override fun onBindViewHolder(viewHolder: MyViewHolder, position: Int) {

        viewHolder.title.text = adList[position].title
        viewHolder.category.text = adList[position].category
        viewHolder.date.text = adList[position].date.toString()
        viewHolder.payment.text = adList[position].payment

        Glide.with(context).load(adList[position].img).apply(options).into(viewHolder.image)

        fusedLocationClient.lastLocation.addOnSuccessListener { location ->
            viewHolder.distance.text =
                SphericalUtil.computeDistanceBetween(adList[position].location, LatLng(location.latitude,location.longitude)).toString()

        }

    }


    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): MyViewHolder {

        val layoutInflater: LayoutInflater = LayoutInflater.from(context)
        val view = layoutInflater.inflate(R.layout.advertisement_row_item,p0,false)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)

        return MyViewHolder(view)
    }

    override fun getItemCount(): Int {

      return  adList.size
    }

    class MyViewHolder(itemView : View) : RecyclerView.ViewHolder(itemView) {

        var title: TextView = itemView.findViewById(R.id.ad_item_title)
        var category: TextView = itemView.findViewById(R.id.ad_item_category)
        var date: TextView = itemView.findViewById(R.id.ad_item_date)
        var distance: TextView = itemView.findViewById(R.id.ad_item_distance)
        var payment: TextView = itemView.findViewById(R.id.ad_item_payment)
        var image: ImageView = itemView.findViewById(R.id.ad_item_thumbnail)

    }
}