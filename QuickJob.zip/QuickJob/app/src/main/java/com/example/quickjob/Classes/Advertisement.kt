package com.example.quickjob.Classes

import com.google.android.gms.maps.model.LatLng
import java.util.*

class Advertisement(var title:String, var desc:String, var date: Date, var img: String, var location: LatLng, var category:String, var payment: String) {
}