package com.example.quickjob.Classes

class ScreenItem(var title:String, var desc:String, var img: Int) {


}